CareConnect Scheduler
Designed and developed "CareConnect Scheduler," an appointment system for small clinics.
It is web app built with HTML, CSS, and PHP, simplifies appointment scheduling for clinics.
Patients book appointments online, while staff manage.
MySQL keeps everything organized, ensuring smooth operation for both patients and staff.
Technologies: HTML5, CSS3, MySQl , Virtual Studio Code
